WE ARE NOT ALONE  -  AARO / PURSUE UAP Video Metadata Pack
============================================================

This pack contains 93 Kodi/XBMC-style .nfo metadata sidecars for the official
U.S. Government UAP videos released by the Department of War / AARO under the
PURSUE program (Releases 01-03, May-June 2026). Every field is sourced from the
videos' own embedded metadata or their official DVIDS pages - nothing invented.

WHY: so you can build a rich, browsable UAP video library in Plex / Jellyfin /
Kodi with real titles, dates, agencies, and full official descriptions instead
of raw "DOD_#########" filenames.

--------------------------------------------------------------------
WHAT YOU GET
--------------------------------------------------------------------
  Season 01/  - 28 sidecars (Release 01, embedded-metadata sourced)
  Season 02/  - 56 sidecars (Release 02, DVIDS-sourced)
  Season 03/  - 9  sidecars (Release 03, DVIDS-sourced)
  catalog.csv - index: id, title, agency, year, type, DVIDS link, filename
  rename_nfo.py - helper to match sidecars to your downloaded files

--------------------------------------------------------------------
STEP 1 - DOWNLOAD THE VIDEOS (from the official source)
--------------------------------------------------------------------
The videos are public domain. Get them from DVIDS (the DoD's distribution site):
  * Open the DVIDS link in catalog.csv for each video (or browse the AARO unit:
    https://www.dvidshub.net/unit/AARO ).
  * Click Download. Files arrive named  DOD_<id>.mp4  (e.g. DOD_111688723.mp4).
  * Bulk releases also live at War.gov's UAP media library.

--------------------------------------------------------------------
STEP 2 - PLACE THE .NFO FILES
--------------------------------------------------------------------
A media server reads a sidecar when the .nfo basename EXACTLY matches the video
basename, in the SAME folder:
    DOD_111688723.mp4   <-  DOD_111688723.nfo      (correct)
The sidecars here are already named DOD_<id>.nfo to match DVIDS downloads.
Just drop each .nfo next to its matching .mp4.

If your download has a different name (some mirrors rename files), run:
    python rename_nfo.py  /path/to/your/videos
It matches by the DOD id inside the filename and renames each .nfo to match.

--------------------------------------------------------------------
STEP 3 - POINT YOUR MEDIA SERVER AT THEM
--------------------------------------------------------------------
PLEX  : use a Movies library + the "XBMCnfoMoviesImport" agent (the default
        "Plex Movie" agent ignores .nfo). Put it above "Local Media Assets",
        enable .nfo import, then Refresh Metadata.
JELLYFIN / EMBY : NFO reading is built in - just Refresh Metadata.
KODI  : enable the local information provider / use the NFO directly.

--------------------------------------------------------------------
SOURCE & LICENSE
--------------------------------------------------------------------
Videos: U.S. Government work, Public Domain. Metadata compiled from official
AARO/DVIDS sources. Pack assembled for wearenotalone.space. Share freely.
